/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
/* eslint-disable max-len */

const assert = require('assert');
Feature('Liking and Unliking Restaurants');

Before(({ I }) => {
  I.amOnPage('/#/like');
});

Scenario('Liking a restaurant', ({ I }) => {
  I.dontSeeElement('.restaurant__item a');

  I.amOnPage('/');
  I.seeElement('.restaurant__item a');
  I.wait();
  I.wait();
  I.wait();
  I.click(locate('.restaurant__item a').first());

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.seeElement('.restaurant__item a');
  I.click(locate('.restaurant__item a').first());
  I.seeElement('#likeButton');

  I.click('#likeButton');
  I.amOnPage('/');
});

Scenario('Unliking a restaurant', ({ I }) => {
  I.dontSeeElement('.restaurant__item a');

  I.amOnPage('/');
  I.seeElement('.restaurant__item a');
  I.wait();
  I.wait();
  I.wait();
  I.click(locate('.restaurant__item a').first());

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.seeElement('.restaurant__item a');
  I.click(locate('.restaurant__item a').first());
  I.seeElement('#likeButton');

  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.dontSeeElement('.restaurant__item a');
});
